@echo off
swipl main.pl
