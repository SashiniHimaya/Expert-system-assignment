#!/bin/sh
swipl main.pl
