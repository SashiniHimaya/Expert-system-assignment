# Testing

The test cases below are designed to exercise different branches of the knowledge base.

## Test Case 1 — Link-local IP / DHCP
Input facts:
- wifi_enabled
- connected_to_wifi
- not(internet_available)
- link_local_ip

Expected:
- Rule 7 should trigger.
- Conclusion: dhcp_or_ip_configuration_problem.
- Action: renew IP configuration and verify DHCP/router configuration.

## Test Case 2 — DNS problem
Input facts:
- wifi_enabled
- connected_to_wifi
- no Internet
- valid_ip
- not(dns_works)

Expected:
- Rule 8 should trigger.
- Conclusion: dns_problem.
- Action: check DNS, ping/nslookup and flush DNS cache when appropriate.

## Test Case 3 — Device-specific problem
Input facts:
- wifi_enabled
- connected_to_wifi
- no Internet
- other_device_works

Expected:
- Rule 5 should trigger.
- Conclusion: device_specific_problem.

## Test Case 4 — Slow connection caused by placement
Input facts:
- wifi_enabled
- connected_to_wifi
- slow_speed
- far_from_router
- alternative_band_available

Expected:
- Rule 10 should trigger.
- Rule 14 may also trigger if connection_drops is supplied; otherwise Rule 21 is not applicable because network visibility is not being tested.
- Conclusion includes weak_signal_or_placement.

## Test Case 5 — Service/router/ISP branch
Input facts:
- wifi_enabled
- connected_to_wifi
- no Internet
- not(other_device_works)
- router_power
- modem_power

Expected:
- Rule 6 triggers because another device is not working.
- Rule 18 and Rule 19 trigger because router/modem are powered.
- Rule 24 can trigger after the same cross-device failure is established.
- Conclusions include possible_service_or_router_problem, restart_router, restart_modem and contact_isp.

## Verification
For every test, verify:
1. The expected rule ID appears in the forward-chaining trace.
2. The expected conclusion is printed.
3. The recommended action matches the rule text.
4. Backward-chaining can explain a derived conclusion using the relevant rule and its conditions.

## Manual UI testing
Run `?- main.` and test:
A. Wi-Fi off / airplane mode on.
B. Wi-Fi connected but no Internet and 169.254.x.x address.
C. Wi-Fi connected but DNS does not work.
D. Slow Wi-Fi while far from router.
E. No Internet on multiple devices.

The expected reasoning should follow the rule table in the report.
