# Wi-Fi Troubleshooting Expert System

## 1. Domain
This expert system provides basic troubleshooting guidance for common Windows Wi-Fi/Internet connectivity problems.

## 2. Technology
- SWI-Prolog
- Command-line interface (CLI)
- Custom forward-chaining and backward-chaining inference engine
- No external Prolog libraries are required.

## 3. Files
- `main.pl` - CLI, questions, demonstrations and test cases.
- `knowledge.pl` - 24 knowledge facts, 24 sourced rules and user questions.
- `engine.pl` - forward/backward chaining engine and explanation support.
- `sources.txt` - external sources used for the knowledge base.
- `TESTING.md` - test cases and expected results.

## 4. Install
Install SWI-Prolog from:
https://www.swi-prolog.org/Download.html

Check:
```text
swipl --version
```

## 5. Run
Open a terminal in this folder and run:
```text
swipl main.pl
```

At the Prolog prompt:
```prolog
?- main.
```

Answer each question with:
- `y` = yes
- `n` = no
- `u` = unknown (the system does not assume yes or no)

The system prints:
1. Rules triggered by forward chaining.
2. Derived conclusions.
3. Backward-chaining explanations/proof trees.

## 6. Run built-in test cases
At the Prolog prompt:
```prolog
?- run_test_cases.
```

## 7. Notes
The system is an educational prototype. It does not replace professional network administration or ISP support. Its conclusions are limited to the rules represented in the knowledge base.

## 8. How the knowledge was obtained
No domain expert interview was conducted. The rules were translated from the public documentation listed in `sources.txt`. The report explains the mapping from source guidance to facts/rules.
