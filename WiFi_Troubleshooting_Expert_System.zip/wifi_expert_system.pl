% Wi-Fi Troubleshooting Expert System
% SINGLE-FILE VERSION
%
% Run:
%   swipl wifi_expert_system.pl
%
% Then:
%   ?- main.
%
% Automated tests:
%   ?- run_test_cases.
%
% This file contains:
%   1. Knowledge base (24 facts + 24 rules)
%   2. User questions
%   3. Forward-chaining inference
%   4. Backward-chaining inference
%   5. Explanation facility
%   6. CLI interface
%   7. Automated test cases
%
% Sources are documented in the assignment report and sources.txt.
% The rules are based on the cited Microsoft and Google support documentation.

:- dynamic observed/1.


% ============================================================
% KNOWLEDGE BASE
% ============================================================

% knowledge.pl
% Wi-Fi Troubleshooting Expert System
% Static domain facts and sourced diagnostic rules.
% Domain knowledge is based on the sources listed in sources.txt.

    domain_fact/3,
    rule/5,
    question/3
]).

% -----------------------------
% Knowledge facts (24)
% -----------------------------
domain_fact(1, wifi_enabled, "Windows can enable/disable Wi-Fi from Network & Internet settings.").
domain_fact(2, airplane_mode_on, "Airplane mode disables wireless communications such as Wi-Fi.").
domain_fact(3, network_visible, "A nearby Wi-Fi network should appear in the available networks list when detectable.").
domain_fact(4, connected_to_wifi, "A device can be connected to Wi-Fi while still lacking Internet access.").
domain_fact(5, internet_available, "Internet availability is a separate condition from local Wi-Fi association.").
domain_fact(6, other_device_works, "Testing the same network on another device helps isolate a device-specific problem.").
domain_fact(7, slow_speed, "Slow Internet can be related to distance, obstacles, congestion, equipment, or provider speed.").
domain_fact(8, far_from_router, "Distance and physical barriers can reduce Wi-Fi performance.").
domain_fact(9, many_devices, "Multiple high-bandwidth activities can reduce available bandwidth.").
domain_fact(10, connection_drops, "Frequent Wi-Fi drops can be related to adapter power settings or wireless-channel interference.").
domain_fact(11, password_correct, "Correct Wi-Fi credentials are required to connect to a protected network.").
domain_fact(12, valid_ip, "A valid IP configuration includes an appropriate IP address, subnet mask, and default gateway.").
domain_fact(13, link_local_ip, "A 169.254.x.x address can indicate failure to obtain an IP address from the router.").
domain_fact(14, dns_works, "DNS should be reachable and able to resolve names for normal name-based Internet access.").
domain_fact(15, proxy_enabled, "A manual or auto-configured proxy can be associated with limited or no Internet access in some Windows scenarios.").
domain_fact(16, recent_update, "A recent update can be relevant when a network connection stopped working properly.").
domain_fact(17, ethernet_cable_ok, "A faulty Ethernet cable can prevent an Ethernet connection; trying another cable can isolate the cable.").
domain_fact(18, alternative_band_available, "Many consumer Wi-Fi routers provide 2.4 GHz and 5 GHz bands that can be tried separately.").
domain_fact(19, router_power, "Router power/status should be checked when diagnosing connectivity problems.").
domain_fact(20, modem_power, "Modem power/status should be checked when Internet access is unavailable.").
domain_fact(21, network_troubleshooter_available, "Windows provides a Network and Internet troubleshooter.").
domain_fact(22, dns_cache, "Windows maintains a DNS client resolver cache that can be flushed.").
domain_fact(23, network_adapter, "The network adapter can be enabled, restarted, or reinstalled as part of troubleshooting.").
domain_fact(24, isp_service, "The Internet service provider controls the Internet service entering the home/network.").

% -----------------------------
% Rules (24)
% Each rule has:
% rule(ID, Conditions, Conclusion, Action, SourceCode)
% Conditions are lists of observed facts.
% -----------------------------

rule(1,  [airplane_mode_on], 
        wireless_disabled, 
        "Turn Airplane mode off and make sure Wi-Fi is on.",
        "MS-WIFI").

rule(2,  [wifi_enabled, not(network_visible)],
        network_not_visible,
        "Check the physical Wi-Fi switch/adapter and restart WLAN AutoConfig; also check supported Wi-Fi frequency.",
        "MS-WIFI").

rule(3,  [wifi_enabled, network_visible, not(connected_to_wifi), not(password_correct)],
        authentication_problem,
        "Verify the Wi-Fi password/credentials and reconnect.",
        "MS-WIFI").

rule(4,  [wifi_enabled, network_visible, not(connected_to_wifi), password_correct],
        connection_setup_problem,
        "Forget/reconnect to the Wi-Fi network and check router/modem connectivity.",
        "MS-WIFI").

rule(5,  [connected_to_wifi, not(internet_available), other_device_works],
        device_specific_problem,
        "Because another device works on the same network, troubleshoot this device's network settings/adapter.",
        "MS-WIFI").

rule(6,  [connected_to_wifi, not(internet_available), not(other_device_works)],
        possible_service_or_router_problem,
        "Check the router/modem and contact the ISP if the problem persists across devices.",
        "MS-WIFI-GOOGLE").

rule(7,  [connected_to_wifi, not(internet_available), link_local_ip],
        dhcp_or_ip_configuration_problem,
        "Run ipconfig /release and ipconfig /renew; verify DHCP/router configuration.",
        "MS-WIFI-DNS").

rule(8,  [connected_to_wifi, not(internet_available), valid_ip, not(dns_works)],
        dns_problem,
        "Check the DNS server, test it with ping/nslookup, and flush the DNS cache with ipconfig /flushdns when appropriate.",
        "MS-DNS").

rule(9,  [connected_to_wifi, not(internet_available)],
        network_reset_recommended,
        "Run the Windows network commands: netsh winsock reset, netsh int ip reset, ipconfig /release, ipconfig /renew, ipconfig /flushdns.",
        "MS-WIFI").

rule(10, [slow_speed, far_from_router],
        weak_signal_or_placement,
        "Move the device closer to the router and reduce physical obstructions.",
        "GOOGLE-SLOW").

rule(11, [slow_speed, many_devices],
        bandwidth_congestion,
        "Reduce high-bandwidth activity or disconnect unused devices; consider discussing bandwidth with the ISP.",
        "GOOGLE-SLOW").

rule(12, [slow_speed, not(far_from_router), not(many_devices)],
        test_network_equipment_or_isp,
        "Test another device and the network speed; if the problem persists, check the router/modem and ISP service.",
        "GOOGLE-SLOW").

rule(13, [connection_drops],
        intermittent_connection,
        "Check Wi-Fi adapter power settings and consider changing the wireless channel to reduce interference.",
        "MS-WIFI").

rule(14, [connection_drops, alternative_band_available],
        band_change_recommended,
        "Try the other available Wi-Fi frequency band (2.4 GHz or 5 GHz).",
        "MS-WIFI").

rule(15, [proxy_enabled, connected_to_wifi, not(internet_available)],
        proxy_check,
        "Check Windows Network & Internet > Proxy and disable an inappropriate manual proxy setting.",
        "MS-WIFI").

rule(16, [recent_update, connection_drops],
        driver_check,
        "Consider uninstalling the network adapter driver and restarting so Windows can reinstall it; keep a backup driver available.",
        "MS-WIFI").

rule(17, [not(ethernet_cable_ok)],
        ethernet_cable_problem,
        "Try another Ethernet cable to determine whether the original cable is the cause.",
        "MS-ETHERNET").

rule(18, [router_power, not(internet_available)],
        restart_router,
        "Restart the router/Wi-Fi equipment and wait for it to finish booting before testing again.",
        "GOOGLE-RESTART").

rule(19, [modem_power, not(internet_available)],
        restart_modem,
        "Restart the modem: disconnect power, wait about 2–3 minutes, reconnect, and wait for the Internet light before testing.",
        "GOOGLE-MODEM").

rule(20, [network_troubleshooter_available, not(internet_available)],
        run_troubleshooter,
        "Run the Windows Network and Internet troubleshooter/Get Help diagnostics.",
        "MS-WIFI").

rule(21, [wifi_enabled, not(network_visible), alternative_band_available],
        frequency_compatibility_check,
        "Try the other Wi-Fi frequency band and check whether the adapter supports the router's selected band.",
        "MS-WIFI").

rule(22, [connected_to_wifi, internet_available, slow_speed, many_devices],
        manage_network_usage,
        "Review connected devices and reduce unused/high-bandwidth activity.",
        "GOOGLE-SLOW").

rule(23, [connected_to_wifi, internet_available, slow_speed, far_from_router, alternative_band_available],
        optimize_wifi_placement,
        "Move closer to the router and test the other available frequency band.",
        "GOOGLE-SLOW-MS-WIFI").

rule(24, [connected_to_wifi, not(internet_available), not(other_device_works), router_power, modem_power],
        contact_isp,
        "If router/modem restart does not restore service across devices, contact the Internet service provider.",
        "GOOGLE-MODEM-GOOGLE-SLOW").

% -----------------------------
% User questions
% -----------------------------
question(wifi_enabled, "Is Wi-Fi switched ON on the computer?", yes_means).
question(airplane_mode_on, "Is Airplane mode currently ON?", yes_means).
question(network_visible, "Can you see your Wi-Fi network in the available networks list?", yes_means).
question(connected_to_wifi, "Is the computer connected to the Wi-Fi network?", yes_means).
question(internet_available, "Can you access the Internet normally right now?", yes_means).
question(other_device_works, "Can another phone/laptop use the same Wi-Fi and access the Internet?", yes_means).
question(slow_speed, "Is the Internet unusually slow?", yes_means).
question(far_from_router, "Is the computer far from the router or separated by several walls/obstructions?", yes_means).
question(many_devices, "Are many devices or high-bandwidth activities using the network?", yes_means).
question(connection_drops, "Does the Wi-Fi connection drop frequently?", yes_means).
question(password_correct, "Are you sure the Wi-Fi password/credentials are correct?", yes_means).
question(valid_ip, "Does the computer have a valid IP address, subnet mask and default gateway?", yes_means).
question(link_local_ip, "Does the computer show a 169.254.x.x IP address?", yes_means).
question(dns_works, "Can the configured DNS server be reached and resolve names?", yes_means).
question(proxy_enabled, "Is a manual/auto-configured proxy currently enabled?", yes_means).
question(recent_update, "Did the connection problem begin after a recent Windows/network update?", yes_means).
question(ethernet_cable_ok, "If using Ethernet, is the cable known to be working correctly?", yes_means).
question(alternative_band_available, "Does the router provide another Wi-Fi band (2.4 GHz/5 GHz) that you can try?", yes_means).
question(router_power, "Is the router powered on and showing normal status lights?", yes_means).
question(modem_power, "Is the modem powered on and showing normal Internet/status lights?", yes_means).

% ============================================================
% INFERENCE ENGINE
% ============================================================

% engine.pl
% Generic forward-chaining and backward-chaining inference engine.

    forward_chain/4,
    backward_chain/4,
    explain_goal/4
]).


% A condition is satisfied when it is an observed positive or explicit negative fact.
condition_holds(not(X), Facts) :-
    !, memberchk(not(X), Facts).
condition_holds(C, Facts) :-
    memberchk(C, Facts).

all_conditions([], _).
all_conditions([C|Cs], Facts) :-
    condition_holds(C, Facts),
    all_conditions(Cs, Facts).

% -----------------------------
% Forward chaining
% -----------------------------
forward_chain(Facts0, Facts, Trace, Conclusions) :-
    forward_loop(Facts0, Facts, [], Trace),
    unique_conclusions(Trace, Conclusions).

forward_loop(Facts, Facts, Trace, Trace) :-
    \+ applicable_new_rule(Facts, _, _, _, _),
    !.
forward_loop(Facts0, Facts, Trace0, Trace) :-
    applicable_new_rule(Facts0, ID, Conditions, Conclusion, Action),
    rule(ID, Conditions, Conclusion, Action, Source),
    append(Facts0, [Conclusion], Facts1),
    append(Trace0, [rule_applied(ID, Conditions, Conclusion, Action, Source)], Trace1),
    forward_loop(Facts1, Facts, Trace1).

applicable_new_rule(Facts, ID, Conditions, Conclusion, Action) :-
    rule(ID, Conditions, Conclusion, Action, _),
    \+ memberchk(Conclusion, Facts),
    all_conditions(Conditions, Facts).

unique_conclusions(Trace, Conclusions) :-
    findall(C, member(rule_applied(_,_,C,_,_), Trace), Cs),
    sort(Cs, Conclusions).

% -----------------------------
% Backward chaining
% -----------------------------
backward_chain(Goal, Facts, Proof, Result) :-
    prove(Goal, Facts, [], Proof),
    ( memberchk(Goal, Facts) -> Result = observed
    ; Result = derived
    ).

prove(Goal, Facts, Seen, [observed(Goal)]) :-
    memberchk(Goal, Facts),
    !.
prove(Goal, Facts, Seen, [rule(ID, Goal, SubProofs)]) :-
    \+ memberchk(Goal, Seen),
    rule(ID, Conditions, Goal, Action, Source),
    prove_conditions(Conditions, Facts, [Goal|Seen], SubProofs),
    !.

prove_conditions([], _, _, []).
prove_conditions([not(X)|Cs], Facts, Seen, [explicitly_not_observed(X)|Rest]) :-
    memberchk(not(X), Facts),
    prove_conditions(Cs, Facts, Seen, Rest).
prove_conditions([C|Cs], Facts, Seen, [P|Rest]) :-
    prove(C, Facts, Seen, P),
    prove_conditions(Cs, Facts, Seen, Rest).

explain_goal(Goal, Facts, Text, Proof) :-
    backward_chain(Goal, Facts, Proof, _),
    ( rule(ID, Conditions, Goal, Action, Source) ->
        format(string(Text),
               "Goal ~w is supported by rule ~w. Conditions: ~w. Recommended action: ~w. Source: ~w.",
               [Goal, ID, Conditions, Action, Source])
    ; format(string(Text), "Goal ~w is directly present in the observed facts.", [Goal])
    ).

% ============================================================
% USER INTERFACE
% ============================================================

% main.pl
% Wi-Fi Troubleshooting Expert System
% Run with SWI-Prolog:
%   swipl main.pl
% then type:
%   ?- main.
%
% This is a CLI interface. It demonstrates:
% 1. User interaction
% 2. Forward chaining
% 3. Backward chaining
% 4. Explanation of conclusions


main :-
    nl,
    writeln('=============================================='),
    writeln(' Wi-Fi Troubleshooting Expert System'),
    writeln('=============================================='),
    writeln('Answer each question with y, n, or u (unknown).'),
    writeln('The system will collect observations and infer'),
    writeln('possible causes/recommended actions.'),
    nl,
    collect_answers(Facts),
    nl,
    writeln('--- FORWARD CHAINING ---'),
    forward_chain(Facts, DerivedFacts, Trace, Conclusions),
    print_forward_trace(Trace),
    print_conclusions(Conclusions),
    nl,
    writeln('--- BACKWARD CHAINING / EXPLANATION ---'),
    explain_relevant(Conclusions, Facts),
    nl,
    writeln('Diagnosis complete. For a new case, run main again.'),
    nl.

collect_answers(Facts) :-
    findall(F, ask_question(F), Raw),
    sort(Raw, Facts).

ask_question(Fact) :-
    question(Fact, Question, _),
    repeat,
      format('~w [y/n/u]: ', [Question]),
      read_line_to_string(user_input, S0),
      string_lower(S0, S),
      ( S = "y" -> !
      ; S = "n" -> Fact = not(Fact), !
      ; S = "u" -> !
      ; writeln('Please enter y, n, or u.'), fail
      ).

print_forward_trace([]) :-
    writeln('No rules were triggered by the supplied positive facts.').
print_forward_trace(Trace) :-
    forall(member(rule_applied(ID, Conditions, Conclusion, Action, Source), Trace),
           format('Rule ~w: IF ~w THEN ~w.~n  Action: ~w~n  Source key: ~w~n',
                  [ID, Conditions, Conclusion, Action, Source])).

print_conclusions([]) :-
    writeln('No additional conclusion was derived.').
print_conclusions(Conclusions) :-
    writeln('Derived conclusions:'),
    forall(member(C, Conclusions), format(' - ~w~n', [C])).

explain_relevant([], _) :-
    writeln('No derived conclusions to explain.').
explain_relevant([Goal|Goals], Facts) :-
    ( explain_goal(Goal, Facts, Text, Proof) ->
        format('~n~w~n', [Text]),
        format('Proof tree: ~w~n', [Proof])
    ; true
    ),
    explain_relevant(Goals, Facts).

% -----------------------------
% Built-in test predicates
% -----------------------------
test_case(1, [wifi_enabled, connected_to_wifi, not(internet_available), link_local_ip]).
test_case(2, [wifi_enabled, connected_to_wifi, not(internet_available), valid_ip, not(dns_works)]).
test_case(3, [wifi_enabled, connected_to_wifi, not(internet_available), other_device_works]).
test_case(4, [wifi_enabled, connected_to_wifi, slow_speed, far_from_router, alternative_band_available]).
test_case(5, [wifi_enabled, connected_to_wifi, not(internet_available), not(other_device_works), router_power, modem_power]).

run_test_cases :-
    forall(test_case(N, Facts),
       ( format('~nTEST CASE ~w~nFacts: ~w~n', [N, Facts]),
         forward_chain(Facts, _, Trace, Conclusions),
         format('Rules triggered: ~w~n', [Trace]),
         format('Conclusions: ~w~n', [Conclusions])
       )).